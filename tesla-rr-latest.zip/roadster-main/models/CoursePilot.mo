model CoursePilot
  "Digital control suggestions for the shared course behavior tree; no force or state writes"
  input Real phase;
  input Real action;
  input Real elapsed;
  input Real position_x;
  input Real velocity_x;
  input Real turn_direction;
  input Real jump_timing_offset_s;
  input Real jump_roll_degrees = 0.0 "Requested signed kickflip rotation; zero retains an upright jump";
  input Real transit_speed_mps(unit="m/s",min=0) = 35.0
    "Requested course cruise speed; zero selects a standing jump without motor acceleration";
  input Real position_y;
  input Real position_z;
  input Real speed;
  input Real velocity_y;
  input Real velocity_z;
  input Real attitude[4] "w, x, y, z";
  input Real rates[3] "Body pitch, yaw, roll in degrees per second";
  input Real yaw;
  input Real up_y;
  input Real airborne;
  input Real wheel_heading;
  input Real wheel_heading_rate "Small-angle rate prediction from the modeled rack";
  parameter Real steering_preview_s = 0.17 "Controller tuning derived from command smoothing + rack lag";
  input Real full_lift_force;
  input Real mass;
  input Real angular_acceleration[3] "Full-bank pitch/yaw/roll authority, rad/s2";
  parameter Real wheelbase = 2.75;
  parameter Real max_heading = 0.45 "Full-scale rack angle in radians";
  parameter Real lookahead_time_s(unit="s") = 1.0 "Path preview longer than the finite rack response";
  parameter Real minimum_lookahead_m(unit="m") = 10.0;
  parameter Real ramp_approach_speed(unit="m/s") = 12.0 "Pilot target for the compact transition";
  parameter Real inverted_stop_z_m(unit="m") = -304.5 "Stop beneath the flat return deck, before its open edge";
  parameter Real ramp_entry_z_m(unit="m") = -300.0 "Course ramp entry in the shared scene frame";
  parameter Real fan_preload_distance_m(unit="m",min=0) = 12.0 "Start fans one approach-second before the ramp to establish suction";
  parameter Real pulse_period = 0.1;
  parameter Real pulse_on = 0.05;
  parameter Real attitude_gain[3] = {4.0,3.5,3.0};
  parameter Real flip_roll_direction = 1.0 "Positive body +Z: counterclockwise viewed from behind toward the nose";
  output Real recommended_yaw_direction;
  output Real jump_impulse_ready;
  output Real jump_roll_progress_deg(start=0,fixed=true) "Integrated measured body roll during the obstacle jump";
  output Real jump_roll_ready;
  output Real takeoff_gate;
  output Real forward;
  output Real reverse;
  output Real left;
  output Real right;
  output Real boost;
  output Real brake;
  output Real lift;
  output Real fan;
  output Real pitch_up;
  output Real pitch_down;
  output Real yaw_left;
  output Real yaw_right;
  output Real roll_left;
  output Real roll_right;
  output Real command_throttle;
  output Real command_steer;
  output Real command_brake;
  output Real command_thrust_z;
  output Real command_thrust_y;
  output Real command_thrust_x;
  output Real command_fan;
  output Real command_lift_fl;
  output Real command_lift_fr;
  output Real command_lift_rl;
  output Real command_lift_rr;
protected
  Real rack_error;
  Real desired_wheel_heading;
  Real lookahead;
  Real target_lateral;
  Real error_quaternion[4];
  Real target_bank;
  Real landing_time;
  Real predicted_lateral_position;
  Real target_rate[3];
  Real rotation_length;
  Real rotation_scale;
  Real rotation_sign;
  Real attitude_error[3];
  Real rate_error[3];
  Real cruise_speed;
  Real lift_acceleration;
  Real available_lift_acceleration;
  Real stopping_height;
  Real jump_target_velocity;
  Real pulse[3];
  Real correcting;
  Real on_ground;
  Real flight;
  Real ramp_flight;
  Real jump_flight;
  Real jump_roll_remaining;
  Real world_up_x;
  Real lateral_lift;
equation
  command_throttle = forward-reverse;
  // Autonomous guidance supplies an analog rack setpoint. Human key
  // suggestions remain discrete and retain the separate keyboard adapter.
  command_steer = noEvent(if phase<6 and on_ground>0.5 and speed>0.5 then
    max(-1.0,min(1.0,-desired_wheel_heading/max_heading)) else 0.0);
  command_brake = brake;
  command_thrust_z = boost;
  command_thrust_y = lift;
  command_thrust_x = yaw_right-yaw_left;
  command_fan = fan;
  command_lift_fl = min(1.0,pitch_up+roll_left);
  command_lift_fr = min(1.0,pitch_up+roll_right);
  command_lift_rl = min(1.0,pitch_down+roll_left);
  command_lift_rr = min(1.0,pitch_down+roll_right);
  // Pure pursuit of the course centerline. Transform the preview point into
  // the measured body frame before converting curvature to a rack angle.
  lookahead = max(minimum_lookahead_m,lookahead_time_s*speed);
  target_lateral = -(1-2*(attitude[3]^2+attitude[4]^2))*position_x
    -2*(attitude[2]*attitude[4]-attitude[1]*attitude[3])*lookahead;
  desired_wheel_heading = -atan(2*wheelbase*target_lateral/(position_x^2+lookahead^2));
  rack_error = wheel_heading+steering_preview_s*wheel_heading_rate-desired_wheel_heading;
  on_ground = noEvent(if airborne<0.2 then 1.0 else 0.0);
  ramp_flight = noEvent(if abs(phase-6)<0.5 and airborne>0.2 then 1.0 else 0.0);
  // Start above the takeoff surface, then retain control through recovery.
  // This is valve guidance: Avian supplies attitude, rates and all motion.
  jump_flight = noEvent(if abs(jump_roll_degrees)>1 and phase>1.5 and phase<3.5
    and airborne>0.2 and (position_y>2.5 or abs(jump_roll_progress_deg)>0.01) then 1.0 else 0.0);
  flight = max(ramp_flight,jump_flight);
  der(jump_roll_progress_deg) = noEvent(if jump_flight>0.5 then rates[3] else 0.0);
  jump_roll_remaining = jump_roll_degrees-jump_roll_progress_deg;
  world_up_x = 2*(attitude[2]*attitude[3]-attitude[1]*attitude[4]);
  // Corner jets produce a net force as well as a roll moment. Correct its
  // lateral impulse during the rotation when the lift vector points back
  // toward the course; waiting until the roll finishes loses that authority.
  // These remain ordinary finite-air valves, with the same cooling limits.
  lateral_lift = noEvent(if ramp_flight>0.5 and up_y>0.8
    and abs(world_up_x)>0.02 and (-1.2*position_x-2.0*velocity_x)*world_up_x>0 then
      min(0.6,max(0.0,(-1.2*position_x-2.0*velocity_x)
        /((full_lift_force/max(1.0,mass))*world_up_x)))
    else if jump_flight>0.5 and up_y> -0.1
    and abs(world_up_x)>0.25 and (-1.2*position_x-2.0*velocity_x)*world_up_x>0 then
      min(0.3,max(0.0,(-1.2*position_x-2.0*velocity_x)
        /((full_lift_force/max(1.0,mass))*world_up_x+1e-9))) else 0.0);
  jump_roll_ready = noEvent(if abs(jump_roll_degrees)<1 then 1.0
    else if abs(jump_roll_remaining)<10 and up_y>0.97 and abs(rates[3])<35 then 1.0 else 0.0);
  left = noEvent(if phase<6 and on_ground>0.5 and rack_error< -0.0015 then 1.0 else 0.0);
  right = noEvent(if phase<6 and on_ground>0.5 and rack_error>0.0015 then 1.0 else 0.0);
  // Target speeds are pilot requests, never physical velocity constraints.
  // Carry the launch speed through both service pads and the cube corridor.
  cruise_speed = noEvent(if phase>0.5 and phase<3.5 then max(0.0,transit_speed_mps)
    else if abs(phase-5)<0.5 and abs(action-7)<0.1 then
      min(6.0,sqrt(10.0*max(0.0,inverted_stop_z_m-position_z)))
    else if abs(phase-4)<0.5 and position_y>13.0 then 6.0
    else if phase>3.5 and phase<5.5 and action<7.5 then
      ramp_approach_speed
    else 0.0);
  // A narrow ballistic clearance corridor. Valve closing contributes a short
  // residual impulse; the target is measured velocity, not an assumed K hold.
  jump_target_velocity = 6.8;
  jump_impulse_ready = noEvent(if velocity_y>=jump_target_velocity then 1.0 else 0.0);
  takeoff_gate = noEvent(if position_z< -72.0+35.0*jump_timing_offset_s then 1.0 else 0.0);
  forward = noEvent(if phase<0.5 and action>0.5 then 1.0
    else if cruise_speed>0 and speed<cruise_speed-0.5 and on_ground>0.5 then 1.0
    else 0.0);
  reverse = 0.0;
  brake = noEvent(if phase<0.5 and action<0.5 then 1.0
    else if abs(phase-5)<0.5 and abs(action-7)<0.1
      and (cruise_speed<0.25 or speed>cruise_speed+0.15) then 1.0
    else if cruise_speed>0 and speed>cruise_speed+2 then 1.0
    else if abs(phase-6)<0.5 and on_ground>0.5 and forward<0.5 and reverse<0.5 then 1.0
    else if phase>6.5 then 1.0 else 0.0);
  fan = noEvent(if phase<3.5 or phase>5.5
    or (phase<4.5 and position_z>ramp_entry_z_m+fan_preload_distance_m)
    or (abs(phase-5)<0.5 and action>7.5) then 0.0 else 1.0);
  // q_error = conjugate(q_body) * q_target, expressed in body axes.
  // Recover wheels-down while retaining the ramp exit heading (+Z).
  landing_time = (velocity_y+sqrt(velocity_y^2+2*9.80665*max(0.0,position_y)))/9.80665;
  predicted_lateral_position = position_x+velocity_x*max(0.5,landing_time);
  recommended_yaw_direction = noEvent(if predicted_lateral_position>0 then 1.0 else -1.0);
  // The inverted ramp already points along +Z. Recover with a roll, then
  // bank the physical lift vector to cancel lateral drift over the road.
  target_bank = noEvent(if ramp_flight>0.5 then
    max(-0.45,min(0.45,atan2(-1.2*position_x-2.0*velocity_x,9.80665)))
    else if jump_flight>0.5 and abs(jump_roll_remaining)<20 and up_y>0.8 then
      max(-0.24,min(0.24,atan2(1.2*position_x+2.0*velocity_x,
        max(9.80665,0.6*full_lift_force/max(1.0,mass))))) else 0.0);
  error_quaternion = noEvent(if jump_flight>0.5 then
    {attitude[1]*cos(target_bank/2)+attitude[4]*sin(target_bank/2),
      -attitude[2]*cos(target_bank/2)-attitude[3]*sin(target_bank/2),
      -attitude[3]*cos(target_bank/2)+attitude[2]*sin(target_bank/2),
      attitude[1]*sin(target_bank/2)-attitude[4]*cos(target_bank/2)} else
    {attitude[2]*sin(target_bank/2)+attitude[3]*cos(target_bank/2),
      attitude[1]*sin(target_bank/2)+attitude[4]*cos(target_bank/2),
      attitude[1]*cos(target_bank/2)-attitude[4]*sin(target_bank/2),
      -attitude[2]*cos(target_bank/2)+attitude[3]*sin(target_bank/2)});
  rotation_length = sqrt(error_quaternion[2]^2+error_quaternion[3]^2+error_quaternion[4]^2);
  // At an inverted exit both half-turns reach the same upright attitude.
  // Select the requested roll branch near inversion instead of letting tiny
  // attitude errors choose clockwise. Once clear, use shortest-path recovery
  // for normal landing trims. Only digital valve suggestions change.
  rotation_sign = noEvent(if flight>0.5 and up_y< -0.8 then
    (if flip_roll_direction*error_quaternion[4]>=0 then 1.0 else -1.0)
    else if error_quaternion[1]>=0 then 1.0 else -1.0);
  rotation_scale = noEvent(rotation_sign
    *2*atan2(rotation_length,rotation_sign*error_quaternion[1])*180/3.141592653589793/max(1e-9,rotation_length));
  attitude_error = rotation_scale*{error_quaternion[2],error_quaternion[3],error_quaternion[4]};
  // Stopping-speed envelope from current finite-gas torque authority. The margin
  // covers valve lag and digital sampling; pitch/roll use half-duty pulses.
  for axis in 1:3 loop
    target_rate[axis] = noEvent(if axis==3 and jump_flight>0.5
      and abs(jump_roll_progress_deg)<abs(jump_roll_degrees)-5 then
      (if jump_roll_remaining>=0 then 1.0 else -1.0)*min(300.0,
        sqrt(2*0.65*max(0.0,angular_acceleration[axis])*0.5
          *abs(jump_roll_remaining)*3.141592653589793/180)*180/3.141592653589793)
      else (if attitude_error[axis]>=0 then 1.0 else -1.0)
      *min(attitude_gain[axis]*abs(attitude_error[axis]),
      sqrt(2*0.65*max(0.0,angular_acceleration[axis])
        *(if axis==2 then 1.0 else 0.5)*abs(attitude_error[axis])*3.141592653589793/180)
        *180/3.141592653589793));
  end for;
  rate_error = {max(-220,min(220,target_rate[1]))-rates[1],
    max(-150,min(150,target_rate[2]))-rates[2],
    max(-300,min(300,target_rate[3]))-rates[3]};
  for axis in 1:3 loop
    // Short correction pulses match the required angular impulse. A high-roll
    // authority bank must not fire a fixed 50 ms pulse for a tiny rate error.
    pulse[axis] = noEvent(if elapsed-floor(elapsed/pulse_period)*pulse_period
      <min(pulse_on,abs(rate_error[axis])*3.141592653589793/180/max(1e-9,angular_acceleration[axis]))
      then 1.0 else 0.0);
  end for;
  pitch_up = noEvent(if flight>0.5 and pulse[1]>0.5 and rate_error[1]>12 then 1.0 else 0.0);
  pitch_down = noEvent(if flight>0.5 and pulse[1]>0.5 and rate_error[1]< -12 then 1.0 else 0.0);
  yaw_left = noEvent(if flight>0.5 and rate_error[2]>8 then 1.0 else 0.0);
  yaw_right = noEvent(if flight>0.5 and rate_error[2]< -8 then 1.0 else 0.0);
  roll_right = noEvent(if flight>0.5 and pulse[3]>0.5 and rate_error[3]>10 then 1.0 else 0.0);
  roll_left = noEvent(if flight>0.5 and pulse[3]>0.5 and rate_error[3]< -10 then 1.0 else 0.0);
  correcting = noEvent(if pitch_up+pitch_down+yaw_left+yaw_right+roll_left+roll_right>0.5 then 1.0 else 0.0);
  boost = noEvent(if phase<0.5 and abs(action-1)<0.5 then 1.0
    else if flight>0.5 and up_y>0.94 and velocity_z>16 and abs(yaw)<0.25 and correcting<0.5 then 1.0 else 0.0);
  // Conservative terminal-force allowance for cooling and pressure drop.
  lift_acceleration = 0.65*full_lift_force*up_y/max(1.0,mass)-9.80665;
  available_lift_acceleration = full_lift_force*up_y/max(1.0,mass)-9.80665;
  stopping_height = velocity_y^2/(2*max(1.0,lift_acceleration));
  lift = max(lateral_lift,noEvent(if abs(phase-2)<0.5 and abs(action-4)<0.5 then 1.0
    // A second timed collective pulse cushions the fast cube-jump landing.
    // Momentum carries the car onward; motor torque is released in the air.
    else if abs(phase-3)<0.5 and airborne>0.8 and up_y>0.94 and velocity_y< -1.5
      and position_y<stopping_height+1.0 and available_lift_acceleration>0.0 then 1.0
    else if flight>0.5 and up_y>0.94 and velocity_y< -2 and available_lift_acceleration>0.0
      and position_y<stopping_height+3.0 and pitch_up+pitch_down+roll_left+roll_right<0.5 then 1.0 else 0.0));
end CoursePilot;
