import "../tools/wheel_state" as wheels;
// One mission tree for manual play, keyboard acceptance, and autopilot.
// Modelica owns continuous pilot-to-actuator coupling; this program owns phases
// and discrete service requests. It never writes forces, poses, velocities or mass.
fn simulation_dependencies(me, ctx) {
    let car = find_path("/World/Roadster");
    let reads=[car];for corner in ["FL","FR","RL","RR"] {reads.push(find_path("/World/Roadster/Wheel_"+corner));}
    for i in 0..3 {reads.push(find_path("/World/JumpBlock"+i.to_string()));}
    #{modelica_entities:[car], entity_reads:reads, entity_writes:[car],
      query_reads:["ReadPorts"], required_inputs:[]}
}
fn readings(car, names) {
    let values = #{};
    for p in query("ReadPorts", #{api_id:car, port_names:names}).ports {
        if p.direction == "out" { values[p.name] = p.value; }
    }
    values
}
fn course_notice(announcements, message) {
    if announcements {notify(message);} else {print(message);}
}
fn phase_node(phase, action, message) {
    once(|me| {
        this.phase = phase;
        cmd("SetPorts", #{target:this.car, writes:[
            ["course_phase", phase*1.0], ["course_action", action*1.0]]});
        course_notice(this.announcements,message);
    })
}
fn action_node(action) {
    once(|me| { cmd("SetPorts", #{target:this.car, writes:[["course_action",action*1.0]]}); })
}
fn healthy(me) {
    // Mission qualification from native pair evidence; never an extra force law.
    let z=world_pos(this.car)[2];
    if this.phase==2 && z< -94.0 && z> -132.0 {
        for cube in this.cubes { for body in this.contact_bodies {
            let c=contact_debug(body,cube);
            if c.total_normal_impulse>1.0 {
                this.failure_code=6.0;return false;
            }
        }}
    }
    let v=readings(this.car,["course_healthy","course_failure_reason"]);
    if v.course_healthy<0.5 {this.failure_code=v.course_failure_reason;return false;}
    true
}
fn launched(me) { readings(this.car,["launch_gate"]).launch_gate > 0.5 }
fn launch_started(me) { readings(this.car,["course_launch_started"]).course_launch_started > 0.5 }
fn in_refill_zone(me) { readings(this.car,["refill_zone"]).refill_zone > 0.5 }
// Completion acknowledges the atomic service boundary. Ongoing nozzle flow
// can consume gas in the same coupled interval; exact fullness is not a receipt.
fn tank_ready(me) { readings(this.car,["instant_services"]).instant_services >= this.expected_service_count }
fn at_takeoff(me) { readings(this.car,["course_takeoff_gate"]).course_takeoff_gate > 0.5 }
fn jump_impulse_ready(me) {readings(this.car,["course_jump_impulse_ready"]).course_jump_impulse_ready>0.5}
fn barrier_reached(me) { readings(this.car,["course_block_crossed"]).course_block_crossed > 0.5 }
fn barrier_cleared(me) { readings(this.car,["jump_clearance"]).jump_clearance > 0.5 }
fn block_count_published(me) { readings(this.car,["course_blocks"]).course_blocks >= this.blocks*1.0 }
fn climbed(me) { readings(this.car,["climb_gate"]).climb_gate > 0.5 }
fn at_crest(me) { readings(this.car,["course_crest_gate"]).course_crest_gate > 0.5 }
fn hanging_still(me) {
    let v=readings(this.car,["position_y","position_z","speed_mps","up_alignment",
        "downforce","vehicle_mass_kg","jet_force_x","jet_force_y","jet_force_z"]);
    v.position_y>17.5 && v.position_z> -307.0 && v.position_z< -302.0
        && v.speed_mps<0.08 && v.up_alignment< -0.97
        && v.downforce>v.vehicle_mass_kg*9.80665*1.2
        && abs(v.jet_force_x)+abs(v.jet_force_y)+abs(v.jet_force_z)<1.0
}
fn in_flight(me) { readings(this.car,["course_airborne_gate"]).course_airborne_gate > 0.5 }
fn roll_ready(me) {readings(this.car,["course_roll_gate"]).course_roll_gate>0.5}
fn landing_ready(me) {
    if readings(this.car,["landing_gate"]).landing_gate<0.5 {return false;}
    if wheels::contact_count("/World/Roadster")!=4 {return false;}
    true
}
fn refill(me) {
    let fields = ["mass_offset","temperature_offset","wall_temperature_offset",
        "refill_count","mechanical_energy_j","stored_energy_j"];
    let names = []; for field in fields { names.push("next_"+field); }
    let boundary = readings(this.car,names);
    this.expected_service_count = boundary.next_refill_count;
    let writes = [];
    for field in fields { writes.push(["instant_"+field,boundary["next_"+field]]); }
    cmd("SetPorts",#{target:this.car,writes:writes});
}
fn count_block(me) {
    this.blocks += 1;
    cmd("SetPorts",#{target:this.car,writes:[["course_blocks_passed",this.blocks*1.0]]});
}
fn refill_node(phase, message, enabled) {
    let nodes=[phase_node(phase,2,message),wait_until(Fn("in_refill_zone"))];
    if enabled {nodes.push(once(Fn("refill")));nodes.push(wait_until(Fn("tank_ready")));}
    seq(nodes)
}
fn barrier_node() {
    seq([wait_until(Fn("barrier_reached")), check(Fn("barrier_cleared")),
         once(Fn("count_block")),wait_until(Fn("block_count_published"))])
}
fn on_start(me, ctx) {
    this.announcements=!ctx.contains("announcements") || ctx.announcements;
    this.car = find_path("/World/Roadster");
    this.failure_code=7.0;this.expected_service_count=0.0;
    this.cubes=[];for i in 0..3 {this.cubes.push(find_path("/World/JumpBlock"+i.to_string()));}
    this.contact_bodies=[this.car];
    this.phase = 0; this.blocks = 0; this.autopilot = false;
    for name in ["TASK_FAILED","runtime.ui.action","intent.edge",
        "roadster.service-brake.apply","roadster.service-brake.release"] {subscribe(name);}
    cmd("SetPorts",#{target:this.car,writes:[["course_phase",0.0],["course_failure_code",0.0],
        ["course_action",0.0],["course_blocks_passed",0.0],["course_autopilot_enable",0.0]]});
    emit("roadster.course.ready",#{});
}
fn task(me, ctx) {
    let services=!ctx.contains("refills") || ctx.refills;
    reactive_seq([
        check(Fn("healthy")),
        seq([
            phase_node(0,0,"LAUNCH: settle, then W + Space to reach 60 mph at the blue gate. Ctrl+P pauses."),
            wait(2.0), action_node(1), wait_until(Fn("launch_started")), wait(0.65), action_node(2),
            wait_until(Fn("launched")),
            refill_node(1,"REFILL 1: drive through the green waypoint; refill is immediate while rolling.",services),
            phase_node(2,3,"JUMP: fans OFF, carry 126 km/h, pulse K precisely at the yellow takeoff line."),
            wait_until(Fn("at_takeoff")), action_node(4), wait_until(Fn("jump_impulse_ready")), action_node(5),
            repeat(3,barrier_node()),
            refill_node(3,"LAND + REFILL 2: pulse K to cushion the landing. Keep rolling; switch fans on just before the ramp.",services),
            phase_node(4,6,"CLIMB: approach the ramp, press F before the curve, then hold W to climb."),
            wait_until(Fn("climbed")),
            phase_node(5,7,"HANG: brake under the return deck. Fan suction holds the car upside down, with jets OFF."),
            retry(120,seq([wait_until(Fn("hanging_still")),
                reactive_seq([check(Fn("hanging_still")),wait(2.0)])])),
            action_node(7.25),
            wait_until(Fn("at_crest")), action_node(8), wait_until(Fn("in_flight")),
            phase_node(6,9,"FLIP: E rolls counterclockwise viewed from behind; Q counterpulses. Keep nose AWAY. R/C and J/L trim."),
            wait_until(Fn("roll_ready")),
            phase_node(6,12,"LAND: nose AWAY from ramp. K cushions descent; Shift brakes after touchdown."),
            // Losing any landing condition resets the native task dwell.
            // This is checkpoint qualification, not a physical contact law.
            retry(60,seq([wait_until(Fn("landing_ready")),
                reactive_seq([check(Fn("landing_ready")),wait(0.5)])])),
            phase_node(7,10,"COURSE COMPLETE: launch, three blocks, fan climb, flip and four-wheel landing."),
        ]),
    ])
}
fn stop_setpoint() {
    [["program_active",0.0],["course_autopilot_enable",0.0],
     ["throttle",0.0],["steer",0.0],["brake",1.0],["thrust_z",0.0],["thrust_y",0.0],
     ["thrust_x",0.0],["lift_fl",0.0],["lift_fr",0.0],["lift_rl",0.0],["lift_rr",0.0]]
}
fn on_event(me, evt, ctx) {
    if this.autopilot && evt.source==this.car &&
        (evt.name=="roadster.service-brake.apply" || evt.name=="roadster.service-brake.release") {
        let value=if evt.name=="roadster.service-brake.apply" {1.0}else{0.0};
        let result=cmd("SetPorts",#{target:this.car,writes:[["brake",value]]});
        if result.ok!=true {throw("Service brake request rejected: "+result);}
    }
    if evt.name == "TASK_FAILED" && evt.source == me {
        this.phase = 8; this.autopilot = false;
        let writes = stop_setpoint(); writes.push(["course_phase",8.0]);writes.push(["course_failure_code",this.failure_code]);
        cmd("SetPorts",#{target:this.car,writes:writes});
        if this.failure_code==8.0 {
            let measured=readings(this.car,["position_y","downforce","fan_seal","vehicle_mass_kg"]);
            let result=cmd("PauseSimulationObject",#{target:this.car,condition:"roadster:adhesion-lost",
                detail:"Fan-supported climb lost road contact at "+measured.position_y.to_string()
                    +" m; suction="+measured.downforce.to_string()+" N, weight="
                    +(measured.vehicle_mass_kg*9.80665).to_string()+" N, seal="+measured.fan_seal.to_string()
                    +". Coupled vehicle paused; retry after reviewing the skirt/contact envelope."});
            if result.ok!=true {throw("Adhesion failure could not pause its coupled vehicle: "+result.to_string());}
        }
        course_notice(this.announcements,"Course missed: see the HUD reason. Retry resets car, air and mission tree.");
    }
    if evt.name == "runtime.ui.action" && evt.value.action == "roadster.autopilot" {
        if this.phase >= 7 && !this.autopilot { course_notice(this.announcements,"Retry the course before starting the autopilot."); return; }
        this.autopilot = !this.autopilot;
        if this.autopilot {
            cmd("SetPorts",#{target:this.car,writes:[["course_autopilot_enable",1.0]]});
            course_notice(this.announcements,"Course autopilot ON. Press any driving or jet key to take over. Ctrl+P still pauses.");
        } else {
            cmd("SetPorts",#{target:this.car,writes:stop_setpoint()});
            course_notice(this.announcements,"Autopilot OFF. Manual controls active.");
        }
    }
    if this.autopilot && evt.name == "intent.edge" && evt.source == this.car && evt.value.edge == "pressed" {
        let movement = ["forward","backward","left","right","brake","thrust","speed_boost",
            "yaw_left","yaw_right","auxiliary_1","auxiliary_2","auxiliary_3","auxiliary_4"];
        if movement.contains(evt.value.intent) {
            this.autopilot = false;
            // Native input has already written the player's complete frame.
            cmd("SetPorts",#{target:this.car,writes:[["course_autopilot_enable",0.0],["program_active",0.0]]});
            course_notice(this.announcements,"Manual takeover: autopilot OFF.");
        }
    }
}
fn on_stop(me,ctx) {
    if this.autopilot { cmd("SetPorts",#{target:this.car,writes:stop_setpoint()}); }
}
