# Dynamics, control and fidelity

USD supplies SI geometry, wheel mounts, separate chassis/roof colliders, Earth
`g = 9.80665 m/s²`, contact materials and typed port connections. Native LunCoSim
integrates body position, tire contact, suspension and wheel shafts. Modelica
reads native motion; it does not integrate a second vehicle trajectory. Rhai
owns discrete course/input/UI policy. Rust contains no Roadster/ramp identity.

## Drive, steering and losses

Two rear motors share 1 MW and 1400 N·m, an assumed 8.4 reduction and 0.97 gear
efficiency. Measured shaft speed and slip limit torque/power. Battery energy,
motor heat and 120 W of headlight load are included in auxiliary consumption.

`SteeringDriver.mo` models a keyboard driver's gradual steering buildup,
1.8/(1+(v/20)²) normalized units/s, with 2.8 units/s return. A separate rack has
0.12 s response and 2 units/s slew. This is an explicit driver assistance
assumption, not a speed-dependent wheel-angle cap. Full 0.45 rad rack travel
remains available. Set `keyboard_steering_assistance=0` for direct analog demand.
The shared Ackermann model supplies actual left/right front wheel headings.
Native tire slip and a single Coulomb cone determine cornering/understeer.

Shift applies bounded opposing axle torque at each physical wheel. The
per-step bound uses wheel inertia to avoid reversing a wheel through zero.
Native tire contact transmits the brake torque through its Coulomb friction
cone. Fan preload changes contact loading without adding inertial mass.
Fans-off on a vertical wall permits sliding.

Release applies one-pedal regeneration, up to 1.8 m/s² and 120 kW, with 80%
electrical recovery through native wheel shafts. Shift brakes are separate.
Rolling loss and body-axis 3D aero oppose motion. No script zeroes velocity.
`VehicleAerodynamics.mo` rotates measured velocity into body axes, applies
quadratic drag and returns world forces. Airbrake/downforce deployment has a
0.2 s response. These are dissipative study coefficients, not a measured aero map.

## Real-gas and thermal state

`CompressedAir.mo` shares one 19-term Lemmon dry-air Helmholtz coefficient set
between reusable functions, storage sizing and the equation-form realtime State.
At 250 kg, 600 L and 293.15 K it gives 437.023 bar absolute. Pressure, dp/dT,
cv and specific internal energy derive from the EOS; internal-energy reference
must be used consistently when accounting mass exchange. See
[CoolProp's thermodynamic identities](https://coolprop.org/fluid_properties/PurePseudoPure.html#thermodynamic-properties-of-fluid)
and [NIST's EOS publication](https://www.nist.gov/publications/thermodynamic-properties-air-and-mixtures-nitrogen-argon-and-oxygen-60-2000-k-pressures).

Between service boundary jumps:

```
rho = m/V
m_dot = mdot_in - mdot_out
m*cv*T_dot = (mdot_in-mdot_out)*T*(dp/dT)_rho/rho + Q_wall + Q_service
p = EOS(rho,T)
```

`TankHeatTransfer.mo` has finite 60 kJ/K wall capacity, 200 W/K gas-wall and
20 W/K ambient-wall conductance. Ambient is 293.15 K; initial wall follows the
editable initial gas temperature. These coefficients are assumptions.

Discharge is inhibited below the live **−130 °C (143.15 K) study guard**. This is not
a Tesla thermal threshold, a fundamental air freezing point, or a claim that
all stored air is usable. No calibrated regulator, multiphase nozzle flow or
moisture/icing model is present. Reviewed sources do not establish Tesla's
actual tank heaters or low-temperature management. Sources describe nitrogen;
this study uses the user's specified dry air.

## Jets, flight and fans

The aggregate throat is 0.002 m², gamma 1.4, efficiency 0.85 and valve response
25 ms. `JetExpansion.mo` uses a fixed area ratio corresponding to exit Mach 3.8,
ideal isentropic expansion and momentum plus exit-pressure thrust. These are
uncalibrated closures. [NASA area–Mach relation](https://www.grc.nasa.gov/www/k-12/BGP/astar.html)
and [nozzle design](https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/nozzle-design/)
provide the generic basis, not Tesla dimensions.

Rear boost, four bottom jets and two front yaw jets share finite gas/flow.
Lift mounts are X=±0.8 m, Z=−0.90/+1.85 m; the nose-side yaw arm is
1.90 m. Rear mounts are Y=−0.02 m above the assumed Y=−0.14 m COM.
`ThrusterMount.mo` includes each actual (point − COM) × force moment. The measured
quaternion rotates moments to world axes. Individual corner commands retain
separate force outputs. There are no invented reverse/downward jet banks.

W/S commands only the motors and A/D only the steering rack, on the ground and
in flight. K commands all four bottom valves with fixed geometry trim, independent of altitude;
R/C command the front/rear pairs; Q/E command the left/right pairs for roll.
I/P/comma/period command individual corner valves and J/L the yaw jets. The
paired controls are authored key aliases for those same
corner commands, with no extra controller or flight-only behavior.
There is no automatic body-rate controller or input mode switch. Releasing a
jet key closes its valve with the 25 ms actuator response; the driver must pulse
opposing jets to arrest rotation. Body rates are measurements only. Native
contact, inertia and the explicit finite forces/moments determine the motion.

The widening shader envelope begins at each exhaust mouth. Modelica publishes
radii, expansion/mixing lengths and exhaust speed; delivered force gates the
animation. A spreading coefficient of 0.08 m/m is assumed. GPU time advects
noise only. Visible streams are qualitative indicators, not validated CFD,
shock cells or a prediction of condensation.

Four rear extractors share a skirted 2 m² plenum. Four native probes measure
body-relative gap and surface alignment. Rotor dynamics, leakage, airflow,
pressure and power determine suction. Limits are 20 kPa / 40 kN / 80 kW /
15000 rpm. Typical sealed demand is much lower than the ceiling. There is no
wall attachment or pose lock. Location/count follow source S10; performance
maps, skirt dimensions and total power remain provisional study assumptions.

## Two explicit external service modes

**Manual finite service:** 20 kg/s maximum, tapering near 250 kg, and a bounded
2 MW thermal jacket. Target temperature is a live 253.15–333.15 K input.
Aftercooling cancels the modeled inflow compression term; the jacket accounts
for wall exchange and drives the target. The external compressor estimate uses
ideal isothermal work at 70% efficiency and COP=1 thermal accounting. Supplied
mass and energy are integrated separately. This is not onboard hardware.

Incoming air is initially stationary in the world. Modelica applies
`F = mdot_in*(0-v)` and the rotational momentum-loading torque while native
mass/inertia update. Relative kinetic energy is removed by accounted external
thermal processing. Driving, jets and manual refill may operate simultaneously.
The test button is available in any attitude; it is a laboratory utility.

**Green waypoint instant service:** an explicitly idealized game boundary.
Modelica calculates cumulative mass/temperature/wall-temperature ledger offsets
that restore 250 kg and the selected temperature. Rhai copies all offsets
atomically through normal inputs. Physical ledgers integrate normal equations
between these externally prescribed jumps. No Rust or script writes body pose,
velocity, mass or pressure. EOS pressure and native mass/inertia follow the new
state on the next synchronization. This route stays event-free for the realtime
fixed-RK4 solver; it does not pretend an enormous finite flow occurred.

The supplied gas is co-moving/co-rotating, preserving native velocities. The
facility supplies the corresponding momentum and mechanical energy. Modelica
tracks added air, kinetic-energy exchange and the EOS gas plus tank-wall stored
energy change. This service does not model real refill equipment or a refill
rate. The manual finite-service budgets remain separate.

## Ramp and course

The practice ramp uses a 50 m transition, 10 m wall and 40 m return arc. The
main skill course uses a compact 18 m lower arc, 0.9 m wall, 11.7 m upper arc
and 5.4 m lip, reaching about 18.9 m. These arc lengths are not radii. The
smoothstep pitch law gives a minimum upper radius near 4.97 m. Exact static
mesh collision supplies the road; markings and checkpoint posts are visual.

At this curvature, a flat plenum between the axles needs additional skirt
extension. With a 2.75 m wheelbase and probes 1.1 m either side of the axle
midpoint, the chord estimate adds about 0.07 m to their 0.25 m uncompressed
flat-road gap at 4.97 m radius. The explicit 0.40 m flexible-skirt study
assumption (`fan_skirt_reach`) provides additional dynamic margin and is qualified
with the actual four probes rather than treating this estimate as exact seal
geometry. Fan area, pressure and electrical power are unchanged. The shorter
0.25 m configuration loses adhesion and is the negative acceptance fixture.
Neither skirt extension nor ramp geometry is manufacturer calibration.

Modelica owns the course pilot and finite steering rack. The analog steering
demand connects directly to the rack inside the same continuous solve; Rhai
selects autopilot ownership and handles discrete control edges and phases.
Pure pursuit transforms the centerline preview into the measured body frame.
The pilot requests a steady 12 m/s ramp approach after the second refill,
avoiding a full-throttle transition followed by abrupt braking on the wall.
Manual controls retain their independent demands and physical limits.

`SkillCourse.mo` owns continuous course observations. Loss of road support above
12 m during the fan-supported climb is an authored mission-envelope failure.
Rhai records measured height, suction, weight and seal through
`PauseSimulationObject`, holding the complete connected vehicle, its Modelica
state and its mission controller. The world and external supervisor remain live.
The shared vessel HUD displays the pause status and Recent Events retains the
measured explanation. Retry resets the scene. This is mission policy,
not a claim that a detached rigid body cannot be integrated numerically.

The production course gate retains all seven SysML criteria: three blocks, both
rolling services, fan-supported upper climb, finite air/mass, aerial recovery
and a cushioned four-wheel return landing. Its current successful run completes
in 29.18 simulated seconds. The explicit early-timing case also passes all seven
criteria; the late case verifies a measured chassis impact and mission miss.
The short-skirt fixture passes seven assertions covering the coupled hold,
frozen inventories/clocks, one sourced explanation and retained world readiness.
Drop-travel and roof-impact behavior remain separate
unqualified conditions.

See [propulsion and mounting analysis](propulsion-analysis.md) for native launch
measurements, Modelica mean-force sizing/impulse, per-bank blowdown and the fixed
rear lift valve gain of 0.486486 required by the unequal front/rear arms.

## Adhesion component boundary

`components/FanAdhesion.usda` contains four invisible native collision-geometry
queries. They are computational probes, not asserted Tesla instruments.
`models/FanAdhesion.mo` owns the surface alignment, seal/leakage, rotor/plenum
law and pressure-center moment. Its mechanical interface is a body-frame force
and moment; its electrical interface is consumed power. Pressure/seal/rpm and
surface proximity are observation outputs for the HUD and course only.

`RoadsterVehicle.mo` is the composition adapter that connects the internal
native observations to that component. `RoadsterPowertrain.mo` receives only
adhesion force and electrical demand: it no longer knows about the four gaps,
surface normals, ray validity or the suction implementation. The native solver
still owns tire reactions, friction and chassis movement. Suction enters the
force sum once; it does not create an attachment, pose correction or gravity
change. The pressure-center moment is `(center_of_pressure-COM) × force`.

The Modelica compiler flattens the nested components into **one participant**.
The extraction adds no communication step and no duplicate rotor state. Four
rays, one algebraic plenum closure and the existing rotor states are retained.
The four-point surface approximation and uncalibrated fan/skirt parameters are
explicit fidelity limits; rough-surface leakage and skirt deformation are not
resolved. A richer internal seal model can replace this implementation while
keeping the same force/moment/power interface.

**Manual service:** Tab or the REFILL AIR button now applies the same immediate
co-moving Modelica service boundary as the green waypoints, including gas/wall
temperature and mass/inertia/energy bookkeeping. The finite external supply
remains an explicitly commanded engineering option through the control API.


## Raycast suspension and laboratory air mode

Four query wheels apply suspension and analytical tire reactions to the single
chassis. Standard attachment fields define radius, inertia, brakes and steering;
the authored spring and damping define each strut. Modelica carries complete
vehicle mass, COM and inertia, including the running gear and stored air.
There are no separately integrated wheel, carrier or knuckle masses.

The cabin mesh and six additional chassis collision parts remain active. These
wheel rays model road support, not a tire carcass or arbitrary obstacle contact.
See [wheel contact](wheel-contact.md) for current evidence and known suspension,
roof-impact qualification boundaries. No Tesla-specific Rust dynamics
are introduced by this realization.

The Air inventory's unlimited-air switch enables an explicitly ideal external
laboratory reservoir. Enabling it invokes the existing instantaneous conditioned
refill. Its co-moving mass flow equals nozzle outflow; same-state enthalpy cancels
blowdown cooling, and its thermal jacket cancels gas/wall heat exchange. Gas
mass, density, temperature, pressure and chassis mass therefore stay steady.
`ideal_supply_air_kg`, `ideal_supply_heat_w`, `ideal_supply_power_w` and
`ideal_supply_energy_j` expose the added mass and external energy boundary.
Turning it off resumes the finite tank equations. No Rust air math or physical
Tesla infinite-air hardware is introduced.
